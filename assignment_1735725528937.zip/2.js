
     
let medicine = [
    {
        name: "Paracetamol",
        manufacturer: "XYZ Pharmaceuticals",
        price: 10,
        category: "Pain Reliever",
        image: "https://via.placeholder.com/100?text=Paracetamol"
    },
    {
        name: "Amoxicillin",
        manufacturer: "ABC Pharma",
        price: 20,
        category: "Antibiotic",
        image: "https://via.placeholder.com/100?text=Amoxicillin"
    },
    {
        name: "Ibuprofen",
        manufacturer: "123 Medicines",
        price: 15,
        category: "Pain Reliever",
        image: "https://via.placeholder.com/100?text=Ibuprofen"
    },
    {
        name: "Metformin",
        manufacturer: "Def Meds",
        price: 30,
        category: "Diabetes",
        image: "https://via.placeholder.com/100?text=Metformin"
    }
];
  
 function filtermedicine(event){ 
  let uservalue = 
    event.target.value.toLowerCase(); 
  let matching=[]; 
  for(let i = 0; i < medicine.length; i++ ) {
  let product= medicine; 
  if 
    (product.toLowerCase().includes(uservalue)){ 
      matching.push(product); 
      } 
  } 
showproducts(matching); 
} 
function showproducts(matching){ 
  let div= 
    document.getElementById("products"); let productlist=""; 
  if (matching.length === 0) {div.innerHTML ='<p>Esa koi  product nhi mila.</p>'; 
  return; 
  } 
for(let i=0 ; i < matching.length;i++) { 
  productlist+=  
    `<p>${matching[i]}</p>`;  
    } 
div.innerHTML = productlist; 
}
showproducts(medicine);



